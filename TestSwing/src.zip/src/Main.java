import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import MyElement.*;
import data.CartData;
import static java.awt.FlowLayout.*;
import javafx.scene.control.TableCell;
import javax.swing.border.LineBorder;

public class Main {
    public static void main(String[] args) throws InterruptedException {
        
        MyFrame myFrame = new MyFrame("C A R T");  
        myFrame.setLocation(200, 200);
        myFrame.setSize(300, 300);
        myFrame.setVisible(true);

        MyPanel myPanel = new MyPanel();
        int myPanelX = 240;
        int myPanelY = 200;
        myPanel.setSize(myPanelX, myPanelY);   
        myPanel.setLocation(20, 20);
        myFrame.add(myPanel);

        MyLabel labelC = new MyLabel(null);


        final MyPanelCart[] cart = new MyPanelCart[10];

        int x = 5;
        int y = 5;

        for (int l = 0; l < 4; l++){      
            for (int v = 0; v < 9; v++){
                cart[l] = new MyPanelCart(l,v);        
                cart[l].setLocation(x, y);

                if (x < myPanelX - 20){
                    x = x + 20;
                } else {
                    x = 5;
                    y = y + 40;
                }
                if (y > myPanelY - 40){
                    y = 5;
                }
                if (v == 8){
                    x = 5;
                    y = y + 45;
                }
                
                myPanel.add(cart[l]);

                labelC.setText(String.valueOf(myPanel.getComponentCount()));
                labelC.setLocation(0, 230);

                myFrame.add(labelC);
                myPanel.repaint();
                myFrame.repaint();
            }
        }
    }   
}
