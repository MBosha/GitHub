
package data;

public class CartData {
    
    public static final String[] cartLaer = {"♠", "♣", "♦", "♥"};
    public static final String[] cartValue = {"6", "7", "8", "9", "10", "J", "Q", "K", "A"};    

    public static String getCartLaer(int index) {
        if ((0 <= index) && (index <= 3)){
            return cartLaer[index];
        }
        return "Z";
    }
    
    public static String getCartValuer(int index) {
        if ((0 <= index) && (index <= 9)){
            return cartValue[index];
        }
        return "Z";
    }
}