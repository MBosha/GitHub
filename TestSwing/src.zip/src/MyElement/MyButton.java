package MyElement;

import javax.swing.JButton;

public class MyButton extends JButton {
    
    
}
