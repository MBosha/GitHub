package MyElement;

import data.CartData;
import java.awt.Color;
import javax.swing.JPanel;
import javax.swing.JWindow;
import javax.swing.border.LineBorder;

public class MyPanelCart extends JPanel{
    
    final MyLabel labelL;
    final MyLabel labelV;
    
    public MyPanelCart(int lear, int value) {
        super();
        this.setLayout(null);
        this.setSize(20, 40);
        LineBorder lineBorder = new LineBorder(Color.ORANGE, 2);
        this.setBorder(lineBorder); 
        labelL = new MyLabel(CartData.getCartLaer(lear));                      
        labelL.setLocation(0, 0);
        this.add(labelL);
        labelV = new MyLabel(CartData.getCartValuer(value)); 
        labelV.setLocation(0, 20);
        this.add(labelV);
    }    
}
