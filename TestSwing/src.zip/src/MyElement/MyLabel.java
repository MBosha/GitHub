package MyElement;

import java.awt.Color;
import java.awt.Font;
import javax.swing.JLabel;
import javax.swing.border.LineBorder;

public class MyLabel extends JLabel {

    public MyLabel(String text) {
        super(text, CENTER);
        this.setLayout(null);
        this.setSize(20, 20);
        LineBorder thickBorder = new LineBorder(Color.ORANGE, 1);
        this.setBorder(thickBorder);
    }            
}
