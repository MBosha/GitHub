package Logic;

import Element.BlockCart;
import java.util.Random;

public class Logic {
    
    public static boolean mixCartBlockStart = false;  
    public static boolean sortCartBlockStart = false; 
}
